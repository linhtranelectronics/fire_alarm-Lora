#ifndef __FLASH_LED__
#define __FLASH_LED__

#include <stdint.h>
#include <Arduino.h>

class FlashLed
{
    public:
    FlashLed(uint8_t pin) : m_pin(pin), m_duration(0), m_lastTriggered(0) {
        pinMode(m_pin, OUTPUT);
    }

    void trigger(uint32_t ms = 20) {
        m_duration = ms;
        m_lastTriggered = millis();
        digitalWrite(m_pin, HIGH);
    }

    void update() {
        if (m_duration > 0 && millis() - m_lastTriggered >= m_duration) {
            digitalWrite(m_pin, LOW);
            m_duration = 0;
        }
    }

private:
    uint8_t m_pin;
    uint32_t m_duration;
    uint32_t m_lastTriggered;
};

#endif // __FLASH_LED__